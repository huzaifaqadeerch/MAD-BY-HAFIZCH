package com.example.timepicker;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.TimePicker;

public class MainActivity extends AppCompatActivity {

    TextView textView;
    TimePicker timePicker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView=findViewById(R.id.textView);
        timePicker=findViewById(R.id.timePicker);

        timePicker.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
            @Override
            public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
                int hour=hourOfDay;
                String ampm;

                if (hour == 0){
                    hour +=12;
                    ampm="AM";
                }else if(hour == 12){
                    ampm ="PM";
                } else if (hour >12) {
                    hour -= 12;
                    ampm ="PM";
                }else {
                    ampm ="AM";
                }
                String formattedHour =(hour<10)? "0" + hour: String.valueOf(hour);
                String formattedMinute=(minute<10)? "0" + minute: String.valueOf(minute);

                String msg ="Time is:" +formattedHour + " : " + formattedMinute + "" + ampm;
                textView.setText(msg);
                textView.setVisibility(ViewGroup.VISIBLE);
            }
        });
    }
}